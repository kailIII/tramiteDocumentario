<?php $__env->startSection('content'); ?>

<div class="col-md-8 col-md-offset-2">
	<div class="panel panel-default">
		<div class="panel-heading"><strong>Lista de Oficinas</strong></div>
				<div class="table-responsive">
				<div class="text-center">
					<table class="table table-hover">
						<thead>
							<tr>
								<th class="text-center">ID</th>
								<th class="text-center">Nombre</th>
								<th class="text-center">Accion</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($offices as $office): ?>
								<tr>
									<td><?php echo e($office->id); ?></td>
									<td><?php echo e($office->name_office); ?></td>
									<td>
									<a href="<?php echo e(route('office.edit', $office->id)); ?>" class="btn btn-default"><span class="glyphicon glyphicon-pencil"></span></a> 
									<a href="<?php echo e(route('office.destroy', $office->id)); ?>" onclick="return confirm('¿Seguro que deseas eliminarlo?')" class="btn btn-danger"><span class="glyphicon glyphicon-minus-sign"></span></a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<?php echo $offices->render(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>