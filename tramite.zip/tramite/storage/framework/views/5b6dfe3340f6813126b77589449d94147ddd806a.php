<?php $__env->startSection('content'); ?>
<div class="col-md-8 col-md-offset-2">
	<div class="panel panel-default">
		<div class="panel-heading"><strong>Lista de Documentos</strong></div>
				<div class="table-responsive">
				<div class="text-center">
					<table class="table table-hover">
						<thead>
							<tr>
								<th class="text-center">ID</th>
								<th class="text-center">Asunto</th>
								<th class="text-center">Oficina</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($documents as $document): ?>
								<tr>
									<td><?php echo e($document->id); ?></td>
									<td><?php echo e($document->asunto); ?></td>
									<td><?php echo e($document->office->name_office); ?></td>
									<td>
									<a href="<?php echo e(route('document.edit', $document->id)); ?>" class="btn btn-default"><span class="glyphicon glyphicon-pencil"></span></a>
									<a href="<?php echo e(route('document.destroy', $document->id)); ?>" onclick="return confirm('¿Seguro que deseas eliminarlo?')" class="btn btn-danger"><span class="glyphicon glyphicon-minus-sign"></span></a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<?php echo $documents->render(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>