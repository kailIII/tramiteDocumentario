<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Nuevo Documento</div>
				<div class="panel-body">
						<?php echo Form::open(['route' => ['document.update', $document->id], 'method' => 'PUT', 'class' => 'form-horizontal']); ?>

						<div class="form-group">
								<?php echo Form::label('asunto', 'Asunto del Documento', array('class' => 'col-md-4 control-label')); ?>

							<div class="col-md-6">
								<?php echo Form::text('asunto', $document->asunto, ['class' => 'form-control', 'required']); ?>

							</div>				
						</div>
						<div class="form-group">
								<?php echo Form::label('label_oficina', 'Oficina Actual', array('class' => 'col-md-4 control-label')); ?>

							<div class="col-md-6">
								<?php echo Form::label('label_oficina', $document->office->name_office, array('class' => 'col-md-4 control-label')); ?>	
							</div>
						</div>
						<div class="form-group">
								<?php echo Form::label('name_office', 'Cambiar por', array('class' => 'col-md-4 control-label')); ?>

							<div class="col-md-6">
								<select type="oficina" class="form-control" name="oficina">
                                	<?php echo $offices = App\Office::all(); ?>

                                	<?php foreach($offices as $office): ?>
                                		<option value="<?php echo $office->id; ?>"><?php echo e($office->name_office); ?></option>
                                	<?php endforeach; ?>
                                </select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
								
								<button type="submit" class="btn btn-primary">
									<i class="fa fa-btn fa-user"></i>Modificar
								</button>
							</div>
						</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>