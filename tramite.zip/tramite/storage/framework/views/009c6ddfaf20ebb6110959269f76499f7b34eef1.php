<?php $__env->startSection('content'); ?>

<div class="col-md-8 col-md-offset-2">
	<div class="panel panel-default">
		<div class="panel-heading"><strong>Seguimiento de un Documento</strong></div>
				<div class="table-responsive">
				<div class="text-center">
					<table class="table table-hover">
						<thead>
							<tr>
								<th class="text-center">Codigo</th>
								<th class="text-center">Estado</th>
								<th class="text-center">Asunto del Documento</th>
								<th class="text-center">Oficina</th>
								<th class="text-center">Usuario</th>
								<th class="text-center">Acción</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($seguimientos as $seguimiento): ?>
								<tr>
									<td><?php echo e($seguimiento->id); ?></td>
									<?php if($seguimiento->estado == 'RECIBIDO'): ?>
										<td><span class="label label-success"><?php echo e($seguimiento->estado); ?></span></td>
									<?php elseif($seguimiento->estado == 'ENVIADO'): ?>
										<td><span class="label label-primary"><?php echo e($seguimiento->estado); ?></span></td>
									<?php elseif($seguimiento->estado == 'ELIMINADO'): ?>
										<td><span class="label label-danger"><?php echo e($seguimiento->estado); ?></span></td>
									<?php endif; ?>
									<td><?php echo e($seguimiento->document->asunto); ?></td>
									<td><?php echo e($seguimiento->office->name_office); ?></td>
									<td><?php echo e($seguimiento->user->name); ?></td>
									<td>
										<a href="#" class="btn btn-primary " title="Enviar"><span class="glyphicon glyphicon-send"></span></a>
										
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<?php echo $seguimientos->render(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>