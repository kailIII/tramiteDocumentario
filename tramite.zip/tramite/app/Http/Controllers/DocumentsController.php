<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Laracasts\Flash\Flash;
use App\Document;
use App\Office;
use App\Seguimiento;

class DocumentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $documents = Document::orderby('id', 'ASC')->paginate(8);
        return view('document.index')->with('documents', $documents);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $offices = Office::all();
        return view('document.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $document = new Document($request->all());
        $document->office_id= $request->oficina;
        $document->save();

        $seguimiento = new Seguimiento($request->all());
        $seguimiento->estado = 'RECIBIDO';
        $seguimiento->document_id = $document->id;
        $seguimiento->office_id = $request->oficina;
        $seguimiento->user_id = $request->user_id;
        $seguimiento->save();
        
        Flash::success("Se ha registrado ". $document->asunto ." de forma exitosa!");
        return redirect()->route('document.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $document = Document::find($id);
        return view('document.edit')->with('document', $document);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $document = Document::find($id);
        $document->office_id= $request->oficina;
        $document->fill($request->all());

        Flash::success("Se modificado por: " . $document->asunto . " de forma exitosa");
        $document->save();
        return redirect()->route('document.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $document = Document::find($id);
        $document->delete();

        Flash::error('El dococumento con el asunto ' . $document->asunto . " ha sido eliminado de forma exitosa.");
        return redirect()->route('document.index');
    }
}
